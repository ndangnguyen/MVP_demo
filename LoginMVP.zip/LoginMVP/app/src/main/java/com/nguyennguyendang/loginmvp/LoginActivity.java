package com.nguyennguyendang.loginmvp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.nguyennguyendang.loginmvp.Presenter.LoginPresenter;
import com.nguyennguyendang.loginmvp.View.ILoginView;

import es.dmoral.toasty.Toasty;

public class LoginActivity extends AppCompatActivity implements ILoginView {

    LoginPresenter loginPresenter;
    Button btLogin;
    EditText etName, etPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        getView();
        setView();
        addListener();
    }

    private void init() {
        loginPresenter = new LoginPresenter(this);
    }

    private void getView() {
        btLogin = findViewById(R.id.btLogin);
        etName = findViewById(R.id.etName);
        etPass = findViewById(R.id.etPass);
    }

    private void setView() {

    }

    private void addListener() {
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginPresenter.checkLogin(etName.getText().toString().trim(), etPass.getText().toString().trim());
            }
        });
    }

    @Override
    public void showLoginError() {
        Toasty.error(this, "Check again!").show();
    }

    @Override
    public void showLoginSuccess() {
        Toasty.success(this, "Login success!").show();
    }
}
