package com.nguyennguyendang.loginmvp.Presenter;

import com.nguyennguyendang.loginmvp.Model.User;
import com.nguyennguyendang.loginmvp.View.ILoginView;

public class LoginPresenter implements ILoginPresenter {

    ILoginView loginView;

    public LoginPresenter(ILoginView loginView) {
        this.loginView = loginView;
    }

    @Override
    public void checkLogin(String name, String pass) {
        User user = new User(name, pass);
        if (user.isValidate()) {
            loginView.showLoginSuccess();
        }
        else {
            loginView.showLoginError();
        }
    }
}
