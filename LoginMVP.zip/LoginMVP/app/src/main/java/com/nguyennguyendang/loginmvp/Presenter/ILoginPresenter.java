package com.nguyennguyendang.loginmvp.Presenter;

public interface ILoginPresenter {
    void checkLogin(String name, String pass);
}
