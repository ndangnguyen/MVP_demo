package com.nguyennguyendang.loginmvp.View;

public interface ILoginView {
    void showLoginError();
    void showLoginSuccess();
}
